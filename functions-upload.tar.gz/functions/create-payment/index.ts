import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { checkRateLimit, sanitizeInput, isValidEmail, corsHeaders } from "../_shared/utils.ts";

interface PaymentRequest {
    serviceSlug: string;
    customerName: string;
    customerEmail: string;
    customerPhone?: string;
}

Deno.serve(async (req: Request) => {
    if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

    try {
        // Enforce Rate Limiting (max 10 requests per minute)
        const rateLimit = checkRateLimit(req, 10, 60000);
        if (!rateLimit.allowed) {
            return new Response(JSON.stringify({ error: "Too many requests. Please try again later." }), {
                status: 429,
                headers: { ...corsHeaders, "Content-Type": "application/json", "Retry-After": Math.ceil(rateLimit.resetIn / 1000).toString() }
            });
        }

        const accessToken = Deno.env.get("ACCESS_TOKEN_PRD") || Deno.env.get("MERCADOPAGO_ACCESS_TOKEN");
        if (!accessToken) throw new Error("Missing ACCESS_TOKEN_PRD");

        const supabaseUrl = Deno.env.get("SELF_HOSTED_DB_URL") || Deno.env.get("SUPABASE_URL")!;
        const supabaseServiceKey = Deno.env.get("SELF_HOSTED_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        const supabase = createClient(supabaseUrl, supabaseServiceKey);

        const body: PaymentRequest & { bookingDate?: string; bookingTime?: string; origin?: string } = await req.json();

        // Sanitize and Validate Inputs
        const serviceSlug = sanitizeInput(body.serviceSlug);
        const customerName = sanitizeInput(body.customerName);
        const customerEmail = sanitizeInput(body.customerEmail).toLowerCase();
        const customerPhone = sanitizeInput(body.customerPhone);
        const bookingDate = sanitizeInput(body.bookingDate);
        const bookingTime = sanitizeInput(body.bookingTime);
        const origin = sanitizeInput(body.origin);

        if (!isValidEmail(customerEmail)) {
            throw new Error("Invalid email format");
        }

        const { data: service, error: serviceError } = await supabase
            .from("services")
            .select("*")
            .eq("slug", serviceSlug)
            .eq("active", true)
            .single();

        if (serviceError || !service) throw new Error(`Service not found: ${serviceSlug}`);

        // Determine Base URL (Prioritize origin from frontend, then SITE_URL secret, then fallback)
        let siteUrl = origin || Deno.env.get("SITE_URL") || "http://localhost:5173";
        // Clean trailing slash if any
        siteUrl = siteUrl.replace(/\/$/, "");

        // Webhook URL (Must be a public URL)
        const functionUrl = `${Deno.env.get("SUPABASE_URL")}/functions/v1/mercadopago-webhook`;

        // Construct metadata
        const metadata = {
            service_slug: serviceSlug,
            customer_email: customerEmail,
            booking_date: bookingDate,
            booking_time: bookingTime
        };

        // Construct full booking ISO string if date/time exist
        let bookingIso = null;
        if (bookingDate && bookingTime) {
            bookingIso = new Date(`${bookingDate}T${bookingTime}:00-03:00`).toISOString();
        }

        // Create payment record first (before MP preference)
        const { data: payment, error: paymentError } = await supabase
            .from("payments")
            .insert({
                customer_name: customerName,
                customer_email: customerEmail,
                customer_phone: customerPhone || null,
                service_type: serviceSlug,
                service_name: service.name,
                amount: service.price,
                mp_status: "pending",
                booking_date: bookingIso,
                metadata: metadata
            })
            .select()
            .single();

        if (paymentError || !payment) {
            throw new Error("Failed to create payment record");
        }

        // Now construct URLs with payment ID
        const successUrl = `${siteUrl}/pago-exitoso?payment_id=${payment.id}&service=${serviceSlug}`;
        const failureUrl = `${siteUrl}/pago-fallido?service=${serviceSlug}`;
        const pendingUrl = `${siteUrl}/pago-pendiente?service=${serviceSlug}`;

        const preferenceData = {
            items: [
                {
                    id: service.slug,
                    title: service.name,
                    quantity: 1,
                    currency_id: "ARS",
                    unit_price: Number(service.price),
                },
            ],
            payer: {
                name: customerName,
                email: customerEmail,
            },
            back_urls: {
                success: successUrl,
                failure: failureUrl,
                pending: pendingUrl,
            },
            notification_url: functionUrl,
            external_reference: payment.id,
            metadata: {
                ...metadata,
                supabase_payment_id: payment.id
            },
        };

        const mpResponse = await fetch("https://api.mercadopago.com/checkout/preferences", {
            method: "POST",
            headers: {
                Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
            },
            body: JSON.stringify(preferenceData),
        });

        if (!mpResponse.ok) {
            const errorText = await mpResponse.text();
            console.error("MercadoPago Error:", errorText);
            throw new Error(`MercadoPago API Error: ${errorText}`);
        }

        const preference = await mpResponse.json();

        // Update payment with MP preference ID
        await supabase
            .from("payments")
            .update({ mp_preference_id: preference.id })
            .eq("id", payment.id);

        return new Response(
            JSON.stringify({
                preference_id: preference.id,
                init_point: preference.init_point,
                sandbox_init_point: preference.sandbox_init_point,
                payment_id: payment.id
            }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );

    } catch (error: any) {
        return new Response(
            JSON.stringify({ error: error.message }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
    }
});
